//
//  main.cpp
//  Sorting1
//
//  Created by David Thacker on 4/11/13.
//  Copyright (c) 2013 David Argyle Thacker. All rights reserved.
//

#include <iostream>
#include <string>
#include <cmath>
#include "SortData.cpp"

using namespace std;

int main(int argc, const char * argv[])
{
    
    SortData sort;
    sort.textToByte(351);
    sort.dataToText();
    
    return 0;
    
}

